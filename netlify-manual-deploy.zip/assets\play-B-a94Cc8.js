import{a8 as o}from"./index-BmUpYGrm.js";
/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=o("Play",[["polygon",{points:"5 3 19 12 5 21 5 3",key:"191637"}]]);export{s as P};
